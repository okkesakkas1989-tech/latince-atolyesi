LATİNCE ATÖLYESİ — ANDROID PWA PAKETİ

Bu paket, HTML sürümünü telefona kurulabilir web uygulamasına dönüştürmek için hazırlanmıştır.

ÖNEMLİ:
- Android'de Chrome üzerinden kurulum seçeneğinin çıkması için bu dosyalar HTTPS destekleyen bir web alanında yayımlanmalıdır.
- ZIP'i açıp dosyaları birlikte bir HTTPS statik site barındırıcısına (ör. GitHub Pages veya Netlify) yükleyin.
- Yayımlanan adresi Android Chrome'da açın; menüden “Uygulamayı yükle” veya “Ana ekrana ekle” seçeneğini kullanın. Menü adı Chrome sürümüne göre değişebilir.
- PWA kurulduktan sonra temel ekran dosyaları çevrimdışı da açılabilir.
- İlerleme verileri tarayıcının yerel depolamasında saklanır. Dosya:// üzerinden kullanılan eski sürümdeki veriler yeni HTTPS adresine otomatik aktarılmaz.
- Bu paket Android APK dosyası değildir; APK oluşturmak için ayrıca paketleme aracı ve imzalama süreci gerekir.
